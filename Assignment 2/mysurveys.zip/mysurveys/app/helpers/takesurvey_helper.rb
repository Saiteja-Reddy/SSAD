module TakesurveyHelper
end

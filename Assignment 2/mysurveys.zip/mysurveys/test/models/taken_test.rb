require 'test_helper'

class TakenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
